assert(check(disk.format(TRACE_DISK, TRACE_DISK_SIZE)) == 0)

local fd = check(disk.open("empty.txt"))
assert(check(disk.read(fd, 64)) == "")
assert(check(disk.getPos(fd)) == 0)
assert(check(disk.seek(fd, 100)) == 0)
disk.close(fd)

fd = check(disk.open("track.txt"))
assert(check(disk.write(fd, "0123456789abcdef")) == 16)
disk.close(fd)

fd = check(disk.open("track.txt"))
assert(check(disk.read(fd, 7)) == "0123456")
assert(check(disk.getPos(fd)) == 7)
assert(check(disk.read(fd, 3)) == "789")
assert(check(disk.getPos(fd)) == 10)
disk.close(fd)

local fd1 = check(disk.open("dup.txt"))
assert(check(disk.write(fd1, "hello world!")) == 12)
local fd2 = check(disk.open("dup.txt"))
assert(check(disk.read(fd2, 5)) == "hello")
assert(check(disk.getPos(fd1)) == 12)
assert(check(disk.getPos(fd2)) == 5)
disk.close(fd1)
disk.close(fd2)

assert(check(disk.unmount()) == 0)
